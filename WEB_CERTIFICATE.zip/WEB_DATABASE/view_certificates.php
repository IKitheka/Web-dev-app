<?php
include 'connection.php';

$sql = "SELECT * FROM certificates ORDER BY issue_date DESC";
$result = $conn->query($sql);

// Handle success/error messages
$message = '';
if (isset($_GET['success']) && $_GET['success'] == '1') {
    $message = '<div class="alert alert-success">Certificate added successfully!</div>';
} elseif (isset($_GET['message'])) {
    if ($_GET['message'] == 'updated') {
        $message = '<div class="alert alert-success">Certificate updated successfully!</div>';
    } elseif ($_GET['message'] == 'deleted') {
        $message = '<div class="alert alert-success">Certificate deleted successfully!</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate Management - View Certificates</title>
    <link rel="stylesheet" href="index.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="main-container">
        <!-- Page Header -->
        <div class="page-header fade-in">
            <h1>CERTIFICATE MANAGEMENT</h1>
            <p class="page-subtitle">Manage and track all certificate records</p>
        </div>

        <!-- Navigation -->
        <nav class="nav-container slide-in">
            <ul class="nav-menu">
                <li class="nav-item active">View Certificates</li>
                <li class="nav-item" onclick="window.location.href='add_certificate.php'">Add Certificate</li>
                <li class="nav-item">Dashboard</li>
                <li class="nav-item">Reports</li>
            </ul>
        </nav>

        <!-- Success/Error Messages -->
        <?php echo $message; ?>

        <!-- Actions Bar -->
        <div class="glass-card mb-4">
            <div class="flex justify-between items-center">
                <h3>Certificate Records</h3>
                <a href="add_certificate.php" class="btn btn-primary">
                    + Add New Certificate
                </a>
            </div>
        </div>

        <!-- Certificates Table -->
        <div class="table-container fade-in">
            <?php if ($result && $result->num_rows > 0): ?>
                <table>
                    <thead class="table-header">
                        <tr>
                            <th>Certificate ID</th>
                            <th>Student ID</th>
                            <th>Internship ID</th>
                            <th>Issue Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($row['certificate_id']); ?></strong>
                                </td>
                                <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                                <td><?php echo htmlspecialchars($row['internship_id']); ?></td>
                                <td>
                                    <?php 
                                    $date = new DateTime($row['issue_date']);
                                    echo $date->format('d/m/Y'); 
                                    ?>
                                </td>
                                <td>
                                    <span class="status-badge status-approved">Active</span>
                                </td>
                                <td class="actions-cell">
                                    <a href="edit_certificate.php?id=<?php echo $row['certificate_id']; ?>" 
                                       class="btn edit-btn">
                                        Edit
                                    </a>
                                    <a href="delete_certificate.php?id=<?php echo $row['certificate_id']; ?>" 
                                       class="btn delete-btn"
                                       onclick="return confirm('Are you sure you want to delete this certificate? This action cannot be undone.')">
                                        Delete
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="glass-card text-center">
                    <h3>No Certificates Found</h3>
                    <p class="mb-3">No certificate records are currently available in the system.</p>
                    <a href="add_certificate.php" class="btn btn-primary">
                        Add Your First Certificate
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <!-- Statistics Cards -->
        <div class="flex gap-4 mt-4">
            <div class="glass-card" style="flex: 1;">
                <h4>Total Certificates</h4>
                <div style="font-size: 2rem; font-weight: 700; color: var(--primary-purple);">
                    <?php echo $result ? $result->num_rows : 0; ?>
                </div>
            </div>
            <div class="glass-card" style="flex: 1;">
                <h4>This Month</h4>
                <div style="font-size: 2rem; font-weight: 700; color: var(--success-green);">
                    <?php 
                    // Count certificates from this month
                    $thisMonth = $conn->query("SELECT COUNT(*) as count FROM certificates WHERE MONTH(issue_date) = MONTH(CURDATE()) AND YEAR(issue_date) = YEAR(CURDATE())");
                    $monthCount = $thisMonth ? $thisMonth->fetch_assoc()['count'] : 0;
                    echo $monthCount;
                    ?>
                </div>
            </div>
            <div class="glass-card" style="flex: 1;">
                <h4>Status</h4>
                <div style="font-size: 1.5rem; font-weight: 600;">
                    <span class="status-badge status-approved">All Active</span>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Add some interactive behavior
        document.addEventListener('DOMContentLoaded', function() {
            // Add hover effects to table rows
            const tableRows = document.querySelectorAll('tbody tr');
            tableRows.forEach(row => {
                row.addEventListener('mouseenter', function() {
                    this.style.transform = 'scale(1.01)';
                });
                row.addEventListener('mouseleave', function() {
                    this.style.transform = 'scale(1)';
                });
            });

            // Add click-to-navigate functionality to nav items
            const navItems = document.querySelectorAll('.nav-item:not(.active)');
            navItems.forEach(item => {
                item.addEventListener('click', function() {
                    // Remove active class from all items
                    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
                    // Add active class to clicked item
                    this.classList.add('active');
                });
            });
        });
    </script>
</body>
</html>

<?php $conn->close(); ?>