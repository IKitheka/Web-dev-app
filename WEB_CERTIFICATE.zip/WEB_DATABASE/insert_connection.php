<?php
require 'connection.php'; // connects to DB

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $certificate_id = $_POST['certificate_id'];
    $student_id = $_POST['student_id'];
    $internship_id = $_POST['internship_id'];
    $issue_date = $_POST['issue_date'];
    
    // Validate required fields
    if (empty($certificate_id) || empty($student_id) || empty($internship_id) || empty($issue_date)) {
        // Redirect back with error
        header("Location: add_certificate.php?error=1");
        exit();
    }
    
    // Prepare SQL statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO certificates (certificate_id, student_id, internship_id, issue_date) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $certificate_id, $student_id, $internship_id, $issue_date);
    
    if ($stmt->execute()) {
        // Success - redirect with success message
        header("Location: add_certificate.php?success=1");
        exit(); // Important: stops PHP from continuing after header
    } else {
        // Database error - redirect with error
        header("Location: add_certificate.php?error=1");
        exit();
    }
    
    $stmt->close();
    $conn->close();
} else {
    // Invalid request method - redirect with error
    header("Location: add_certificate.php?error=1");
    exit();
}
?>