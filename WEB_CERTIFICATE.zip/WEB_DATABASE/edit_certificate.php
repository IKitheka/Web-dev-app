<?php
include 'connection.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM certificates WHERE certificate_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $certificate = $result->fetch_assoc();
} else {
    die("Certificate ID not found.");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Certificate</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <h2>Edit Certificate</h2>
    <form action="update_certificate.php" method="post">
        <input type="hidden" name="certificate_id" value="<?php echo $certificate['certificate_id']; ?>">

        <label>Student ID:</label>
        <input type="text" name="student_id" value="<?php echo $certificate['student_id']; ?>" required><br><br>

        <label>Issue Date:</label>
        <input type="date" name="issue_date" value="<?php echo $certificate['issue_date']; ?>" required><br><br>

        <label>Internship ID:</label>
        <input type="text" name="internship_id" value="<?php echo $certificate['internship_id']; ?>" required><br><br>

        <input type="submit" value="Update Certificate">
    </form>
</body>
</html>
