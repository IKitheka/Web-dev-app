<?php
include 'connection.php';

// Handle report generation
$reportType = isset($_POST['report_type']) ? $_POST['report_type'] : '';
$dateFrom = isset($_POST['date_from']) ? $_POST['date_from'] : '';
$dateTo = isset($_POST['date_to']) ? $_POST['date_to'] : '';
$studentId = isset($_POST['student_id']) ? $_POST['student_id'] : '';
$internshipId = isset($_POST['internship_id']) ? $_POST['internship_id'] : '';

$reportData = null;
$reportTitle = '';

if ($reportType) {
    switch ($reportType) {
        case 'date_range':
            $sql = "SELECT * FROM certificates WHERE issue_date BETWEEN ? AND ? ORDER BY issue_date DESC";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $dateFrom, $dateTo);
            $stmt->execute();
            $reportData = $stmt->get_result();
            $reportTitle = "Certificates issued between " . date('d/m/Y', strtotime($dateFrom)) . " and " . date('d/m/Y', strtotime($dateTo));
            break;
            
        case 'student':
            $sql = "SELECT * FROM certificates WHERE student_id = ? ORDER BY issue_date DESC";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $studentId);
            $stmt->execute();
            $reportData = $stmt->get_result();
            $reportTitle = "Certificates for Student ID: " . htmlspecialchars($studentId);
            break;
            
        case 'internship':
            $sql = "SELECT * FROM certificates WHERE internship_id = ? ORDER BY issue_date DESC";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $internshipId);
            $stmt->execute();
            $reportData = $stmt->get_result();
            $reportTitle = "Certificates for Internship ID: " . htmlspecialchars($internshipId);
            break;
            
        case 'monthly':
            $sql = "SELECT * FROM certificates WHERE MONTH(issue_date) = MONTH(CURDATE()) AND YEAR(issue_date) = YEAR(CURDATE()) ORDER BY issue_date DESC";
            $reportData = $conn->query($sql);
            $reportTitle = "Monthly Report - " . date('F Y');
            break;
            
        case 'summary':
            // This will be handled differently as it's a summary report
            $reportTitle = "Certificate Summary Report";
            break;
    }
}

// Get summary statistics for summary report
if ($reportType == 'summary') {
    $totalCerts = $conn->query("SELECT COUNT(*) as count FROM certificates")->fetch_assoc()['count'];
    $thisMonth = $conn->query("SELECT COUNT(*) as count FROM certificates WHERE MONTH(issue_date) = MONTH(CURDATE()) AND YEAR(issue_date) = YEAR(CURDATE())")->fetch_assoc()['count'];
    $thisYear = $conn->query("SELECT COUNT(*) as count FROM certificates WHERE YEAR(issue_date) = YEAR(CURDATE())")->fetch_assoc()['count'];
    
    $studentStats = $conn->query("SELECT student_id, COUNT(*) as count FROM certificates GROUP BY student_id ORDER BY count DESC LIMIT 10");
    $internshipStats = $conn->query("SELECT internship_id, COUNT(*) as count FROM certificates GROUP BY internship_id ORDER BY count DESC LIMIT 10");
    $monthlyStats = $conn->query("SELECT MONTHNAME(issue_date) as month, COUNT(*) as count FROM certificates WHERE YEAR(issue_date) = YEAR(CURDATE()) GROUP BY MONTH(issue_date) ORDER BY MONTH(issue_date)");
}

// Get unique students and internships for dropdowns
$students = $conn->query("SELECT DISTINCT student_id FROM certificates ORDER BY student_id");
$internships = $conn->query("SELECT DISTINCT internship_id FROM certificates ORDER BY internship_id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate Management - Reports</title>
    <link rel="stylesheet" href="index.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="main-container">
        <!-- Page Header -->
        <div class="page-header fade-in">
            <h1>REPORTS</h1>
            <p class="page-subtitle">Generate detailed certificate reports and analytics</p>
        </div>

        <!-- Navigation -->
        <nav class="nav-container slide-in">
            <ul class="nav-menu">
                <li class="nav-item" onclick="window.location.href='index.php'">View Certificates</li>
                <li class="nav-item" onclick="window.location.href='add_certificate.php'">Add Certificate</li>
                <li class="nav-item" onclick="window.location.href='dashboard.php'">Dashboard</li>
                <li class="nav-item active">Reports</li>
            </ul>
        </nav>

        <!-- Report Generation Form -->
        <div class="glass-card mb-4">
            <h3>Generate Report</h3>
            <form method="POST" class="report-form" id="reportForm">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="report_type">Report Type</label>
                        <select name="report_type" id="report_type" required onchange="toggleFields()">
                            <option value="">Select Report Type</option>
                            <option value="date_range" <?php echo $reportType == 'date_range' ? 'selected' : ''; ?>>Date Range</option>
                            <option value="student" <?php echo $reportType == 'student' ? 'selected' : ''; ?>>By Student</option>
                            <option value="internship" <?php echo $reportType == 'internship' ? 'selected' : ''; ?>>By Internship</option>
                            <option value="monthly" <?php echo $reportType == 'monthly' ? 'selected' : ''; ?>>This Month</option>
                            <option value="summary" <?php echo $reportType == 'summary' ? 'selected' : ''; ?>>Summary Report</option>
                        </select>
                    </div>
                    
                    <div class="form-group date-fields" style="display: none;">
                        <label for="date_from">From Date</label>
                        <input type="date" name="date_from" id="date_from" value="<?php echo $dateFrom; ?>">
                    </div>
                    
                    <div class="form-group date-fields" style="display: none;">
                        <label for="date_to">To Date</label>
                        <input type="date" name="date_to" id="date_to" value="<?php echo $dateTo; ?>">
                    </div>
                    
                    <div class="form-group student-field" style="display: none;">
                        <label for="student_id">Student ID</label>
                        <select name="student_id" id="student_id">
                            <option value="">Select Student</option>
                            <?php if ($students && $students->num_rows > 0): ?>
                                <?php while ($student = $students->fetch_assoc()): ?>
                                    <option value="<?php echo $student['student_id']; ?>" 
                                            <?php echo $studentId == $student['student_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($student['student_id']); ?>
                                    </option>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    
                    <div class="form-group internship-field" style="display: none;">
                        <label for="internship_id">Internship ID</label>
                        <select name="internship_id" id="internship_id">
                            <option value="">Select Internship</option>
                            <?php if ($internships && $internships->num_rows > 0): ?>
                                <?php while ($internship = $internships->fetch_assoc()): ?>
                                    <option value="<?php echo $internship['internship_id']; ?>"
                                            <?php echo $internshipId == $internship['internship_id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($internship['internship_id']); ?>
                                    </option>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Generate Report</button>
                    <?php if ($reportData || $reportType == 'summary'): ?>
                        <button type="button" class="btn btn-secondary" onclick="printReport()">Print Report</button>
                        <button type="button" class="btn btn-secondary" onclick="exportToCSV()">Export CSV</button>
                    <?php endif; ?>
                </div>
            </form>
        </div>

        <!-- Report Results -->
        <?php if ($reportData || $reportType == 'summary'): ?>
            <div class="glass-card report-container" id="reportContainer">
                <div class="report-header">
                    <h2><?php echo $reportTitle; ?></h2>
                    <p class="report-date">Generated on: <?php echo date('d/m/Y H:i:s'); ?></p>
                </div>

                <?php if ($reportType == 'summary'): ?>
                    <!-- Summary Report -->
                    <div class="summary-report">
                        <div class="summary-stats">
                            <div class="summary-card">
                                <h4>Total Certificates</h4>
                                <div class="summary-number"><?php echo $totalCerts; ?></div>
                            </div>
                            <div class="summary-card">
                                <h4>This Month</h4>
                                <div class="summary-number"><?php echo $thisMonth; ?></div>
                            </div>
                            <div class="summary-card">
                                <h4>This Year</h4>
                                <div class="summary-number"><?php echo $thisYear; ?></div>
                            </div>
                        </div>

                        <div class="summary-sections">
                            <div class="summary-section">
                                <h4>Top Students by Certificate Count</h4>
                                <table class="summary-table">
                                    <thead>
                                        <tr>
                                            <th>Student ID</th>
                                            <th>Certificate Count</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if ($studentStats && $studentStats->num_rows > 0): ?>
                                            <?php while ($stat = $studentStats->fetch_assoc()): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($stat['student_id']); ?></td>
                                                    <td><?php echo $stat['count']; ?></td>
                                                </tr>
                                            <?php endwhile; ?>
                                        <?php else: ?>
                                            <tr><td colspan="2">No data available</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="summary-section">
                                <h4>Top Internships by Certificate Count</h4>
                                <table class="summary-table">
                                    <thead>
                                        <tr>
                                            <th>Internship ID</th>
                                            <th>Certificate Count</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if ($internshipStats && $internshipStats->num_rows > 0): ?>
                                            <?php while ($stat = $internshipStats->fetch_assoc()): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars($stat['internship_id']); ?></td>
                                                    <td><?php echo $stat['count']; ?></td>
                                                </tr>
                                            <?php endwhile; ?>
                                        <?php else: ?>
                                            <tr><td colspan="2">No data available</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="summary-section">
                                <h4>Monthly Breakdown (Current Year)</h4>
                                <table class="summary-table">
                                    <thead>
                                        <tr>
                                            <th>Month</th>
                                            <th>Certificate Count</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if ($monthlyStats && $monthlyStats->num_rows > 0): ?>
                                            <?php while ($stat = $monthlyStats->fetch_assoc()): ?>
                                                <tr>
                                                    <td><?php echo $stat['month']; ?></td>
                                                    <td><?php echo $stat['count']; ?></td>
                                                </tr>
                                            <?php endwhile; ?>
                                        <?php else: ?>
                                            <tr><td colspan="2">No data available</td></tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Regular Report -->
                    <?php if ($reportData && $reportData->num_rows > 0): ?>
                        <div class="report-summary">
                            <p><strong>Total Records:</strong> <?php echo $reportData->num_rows; ?></p>
                        </div>
                        
                        <table class="report-table">
                            <thead>
                                <tr>
                                    <th>Certificate ID</th>
                                    <th>Student ID</th>
                                    <th>Internship ID</th>
                                    <th>Issue Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $reportData->fetch_assoc()): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($row['certificate_id']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($row['student_id']); ?></td>
                                        <td><?php echo htmlspecialchars($row['internship_id']); ?></td>
                                        <td>
                                            <?php 
                                            $date = new DateTime($row['issue_date']);
                                            echo $date->format('d/m/Y'); 
                                            ?>
                                        </td>
                                        <td><span class="status-badge status-approved">Active</span></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="no-data">
                            <h4>No Records Found</h4>
                            <p>No certificates match the selected criteria.</p>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- Quick Reports Section -->
        <div class="glass-card">
            <h3>Quick Reports</h3>
            <div class="quick-reports">
                <button class="quick-report-btn" onclick="generateQuickReport('today')">
                    <div class="quick-report-icon"></div>
                    <div class="quick-report-text">
                        <strong>Today's Certificates</strong>
                        <span>View certificates issued today</span>
                    </div>
                </button>
                
                <button class="quick-report-btn" onclick="generateQuickReport('week')">
                    <div class="quick-report-icon"></div>
                    <div class="quick-report-text">
                        <strong>This Week</strong>
                        <span>Weekly certificate report</span>
                    </div>
                </button>
                
                <button class="quick-report-btn" onclick="generateQuickReport('month')">
                    <div class="quick-report-icon"></div>
                    <div class="quick-report-text">
                        <strong>Monthly Report</strong>
                        <span>Current month overview</span>
                    </div>
                </button>
                
                <button class="quick-report-btn" onclick="generateQuickReport('year')">
                    <div class="quick-report-icon"></div>
                    <div class="quick-report-text">
                        <strong>Yearly Summary</strong>
                        <span>Complete year analysis</span>
                    </div>
                </button>
            </div>
        </div>
    </div>

    <script>
        function toggleFields() {
            const reportType = document.getElementById('report_type').value;
            const dateFields = document.querySelectorAll('.date-fields');
            const studentField = document.querySelector('.student-field');
            const internshipField = document.querySelector('.internship-field');
            
            // Hide all fields first
            dateFields.forEach(field => field.style.display = 'none');
            studentField.style.display = 'none';
            internshipField.style.display = 'none';
            
            // Show relevant fields based on report type
            switch(reportType) {
                case 'date_range':
                    dateFields.forEach(field => field.style.display = 'block');
                    break;
                case 'student':
                    studentField.style.display = 'block';
                    break;
                case 'internship':
                    internshipField.style.display = 'block';
                    break;
            }
        }

        function printReport() {
            const reportContainer = document.getElementById('reportContainer');
            const originalContent = document.body.innerHTML;
            
            document.body.innerHTML = `
                <div style="font-family: Arial, sans-serif; color: #000; background: #fff; padding: 20px;">
                    ${reportContainer.innerHTML}
                </div>
            `;
            
            window.print();
            document.body.innerHTML = originalContent;
            location.reload();
        }

        function exportToCSV() {
            const reportType = '<?php echo $reportType; ?>';
            let csvContent = '';
            
            if (reportType === 'summary') {
                // Export summary data
                csvContent = 'Certificate Summary Report\n';
                csvContent += 'Generated on: <?php echo date("d/m/Y H:i:s"); ?>\n\n';
                csvContent += 'Total Certificates,<?php echo $totalCerts; ?>\n';
                csvContent += 'This Month,<?php echo $thisMonth; ?>\n';
                csvContent += 'This Year,<?php echo $thisYear; ?>\n';
            } else {
                // Export table data
                const table = document.querySelector('.report-table');
                if (table) {
                    const rows = table.querySelectorAll('tr');
                    rows.forEach(row => {
                        const cells = row.querySelectorAll('th, td');
                        const rowData = Array.from(cells).map(cell => {
                            return '"' + cell.textContent.trim().replace(/"/g, '""') + '"';
                        });
                        csvContent += rowData.join(',') + '\n';
                    });
                }
            }
            
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', 'certificate_report_' + new Date().toISOString().split('T')[0] + '.csv');
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        function generateQuickReport(period) {
            const form = document.getElementById('reportForm');
            const reportTypeSelect = document.getElementById('report_type');
            
            switch(period) {
                case 'today':
                    const today = new Date().toISOString().split('T')[0];
                    reportTypeSelect.value = 'date_range';
                    document.getElementById('date_from').value = today;
                    document.getElementById('date_to').value = today;
                    break;
                case 'week':
                    const weekAgo = new Date();
                    weekAgo.setDate(weekAgo.getDate() - 7);
                    reportTypeSelect.value = 'date_range';
                    document.getElementById('date_from').value = weekAgo.toISOString().split('T')[0];
                    document.getElementById('date_to').value = new Date().toISOString().split('T')[0];
                    break;
                case 'month':
                    reportTypeSelect.value = 'monthly';
                    break;
                case 'year':
                    reportTypeSelect.value = 'summary';
                    break;
            }
            
            toggleFields();
            form.submit();
        }

        // Initialize form fields on page load
        document.addEventListener('DOMContentLoaded', function() {
            toggleFields();
            
            // Add animation to quick report buttons
            const quickBtns = document.querySelectorAll('.quick-report-btn');
            quickBtns.forEach(btn => {
                btn.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-3px) scale(1.02)';
                });
                btn.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0) scale(1)';
                });
            });
        });
    </script>

    <style>
        .report-form {
            margin-bottom: 1.5rem;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .form-group label {
            font-weight: 500;
            color: rgba(255, 255, 255, 0.9);
        }

        .form-group select,
        .form-group input {
            padding: 0.75rem;
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            background: rgba(255, 255, 255, 0.05);
            color: white;
            font-size: 0.9rem;
        }

        .form-group select:focus,
        .form-group input:focus {
            outline: none;
            border-color: var(--primary-purple);
            box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.2);
        }

        .form-actions {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .report-container {
            margin-bottom: 2rem;
        }

        .report-header {
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .report-header h2 {
            margin: 0 0 0.5rem 0;
            color: var(--primary-purple);
        }

        .report-date {
            margin: 0;
            opacity: 0.7;
            font-size: 0.9rem;
        }

        .report-summary {
            margin-bottom: 1.5rem;
            padding: 1rem;
            background: rgba(139, 92, 246, 0.1);
            border-radius: 8px;
            border: 1px solid rgba(139, 92, 246, 0.2);
        }

        .report-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 1rem;
        }

        .report-table th,
        .report-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .report-table th {
            background: rgba(255, 255, 255, 0.05);
            font-weight: 600;
        }

        .summary-report {
            display: flex;
            flex-direction: column;
            gap: 2rem;
        }

        .summary-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
        }

        .summary-card {
            padding: 1.5rem;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 12px;
            border: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
        }

        .summary-card h4 {
            margin: 0 0 1rem 0;
            opacity: 0.8;
        }

        .summary-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary-purple);
        }

        .summary-sections {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
        }

        .summary-section h4 {
            margin: 0 0 1rem 0;
            color: var(--primary-purple);
        }

        .summary-table {
            width: 100%;
            border-collapse: collapse;
        }

        .summary-table th,
        .summary-table td {
            padding: 0.5rem;
            text-align: left;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .summary-table th {
            background: rgba(255, 255, 255, 0.05);
            font-weight: 600;
            font-size: 0.9rem;
        }

        .no-data {
            text-align: center;
            padding: 2rem;
            opacity: 0.7;
        }

        .quick-reports {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
        }

        .quick-report-btn {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1.5rem;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: white;
            text-align: left;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .quick-report-btn:hover {
            background: rgba(255, 255, 255, 0.1);
            border-color: var(--primary-purple);
        }

        .quick-report-icon {
            font-size: 2rem;
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(139, 92, 246, 0.2);
            border-radius: 10px;
        }

        .quick-report-text {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }

        .quick-report-text strong {
            font-size: 1.1rem;
        }

        .quick-report-text span {
            font-size: 0.9rem;
            opacity: 0.7;
        }

        @media (max-width: 768px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .summary-stats {
                grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            }
            
            .summary-sections {
                grid-template-columns: 1fr;
            }
            
            .quick-reports {
                grid-template-columns: 1fr;
            }
        }

        @media print {
            body {
                background: white !important;
                color: black !important;
            }
            
            .glass-card {
                background: white !important;
                border: 1px solid #ccc !important;
            }
            
            .btn {
                display: none !important;
            }
            
            .nav-container {
                display: none !important;
            }
        }
        /* Add this CSS to your existing styles to fix the white dropdown issue */

.form-group select {
    padding: 0.75rem;
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.05);
    color: white;
    font-size: 0.9rem;
    /* Add these properties to style the dropdown */
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='white' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6,9 12,15 18,9'%3e%3c/polyline%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-position: right 0.75rem center;
    background-size: 1em;
    padding-right: 2.5rem;
}

/* Style the dropdown options */
.form-group select option {
    background: #1a1a2e;
    color: white;
    padding: 0.5rem;
    border: none;
}

/* Alternative approach - style the select when opened */
.form-group select:focus {
    outline: none;
    border-color: var(--primary-purple);
    box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.2);
    background: rgba(255, 255, 255, 0.08);
}

/* For WebKit browsers (Chrome, Safari) */
.form-group select::-webkit-scrollbar {
    width: 8px;
}

.form-group select::-webkit-scrollbar-track {
    background: rgba(255, 255, 255, 0.1);
    border-radius: 4px;
}

.form-group select::-webkit-scrollbar-thumb {
    background: rgba(139, 92, 246, 0.6);
    border-radius: 4px;
}

.form-group select::-webkit-scrollbar-thumb:hover {
    background: rgba(139, 92, 246, 0.8);
}

/* Additional styling for better dark theme consistency */
.form-group input[type="date"] {
    padding: 0.75rem;
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 8px;
    background: rgba(255, 255, 255, 0.05);
    color: white;
    font-size: 0.9rem;
    color-scheme: dark; /* This helps with date picker styling */
}

.form-group input[type="date"]:focus {
    outline: none;
    border-color: var(--primary-purple);
    box-shadow: 0 0 0 2px rgba(139, 92, 246, 0.2);
}

/* Date input calendar icon styling */
.form-group input[type="date"]::-webkit-calendar-picker-indicator {
    filter: invert(1);
    cursor: pointer;
}

/* Firefox specific styling */
@-moz-document url-prefix() {
    .form-group select {
        background-image: none;
        padding-right: 0.75rem;
    }
}
    </style>
</body>
</html>

<?php $conn->close(); ?>