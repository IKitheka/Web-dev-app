<?php
include 'connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $certificate_id = $_POST['certificate_id'];
    $student_id = $_POST['student_id'];
    $issue_date = $_POST['issue_date'];
    $internship_id = $_POST['internship_id'];

    $stmt = $conn->prepare("UPDATE certificates SET student_id = ?, issue_date = ?, internship_id = ? WHERE certificate_id = ?");
    $stmt->bind_param("sssi", $student_id, $issue_date, $internship_id, $certificate_id);

    if ($stmt->execute()) {
        header("Location: view_certificates.php?message=updated");
        exit();
    } else {
        echo "Update failed: " . $conn->error;
    }

    $stmt->close();
}
$conn->close();
?>
