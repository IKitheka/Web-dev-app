<?php
include 'connection.php';

// Get dashboard statistics
$totalCertificates = $conn->query("SELECT COUNT(*) as count FROM certificates")->fetch_assoc()['count'];
$thisMonth = $conn->query("SELECT COUNT(*) as count FROM certificates WHERE MONTH(issue_date) = MONTH(CURDATE()) AND YEAR(issue_date) = YEAR(CURDATE())")->fetch_assoc()['count'];
$thisWeek = $conn->query("SELECT COUNT(*) as count FROM certificates WHERE WEEK(issue_date) = WEEK(CURDATE()) AND YEAR(issue_date) = YEAR(CURDATE())")->fetch_assoc()['count'];
$today = $conn->query("SELECT COUNT(*) as count FROM certificates WHERE DATE(issue_date) = CURDATE()")->fetch_assoc()['count'];

// Get recent certificates
$recentCertificates = $conn->query("SELECT * FROM certificates ORDER BY issue_date DESC LIMIT 5");

// Get monthly data for chart
$monthlyData = $conn->query("
    SELECT 
        MONTH(issue_date) as month,
        YEAR(issue_date) as year,
        COUNT(*) as count,
        MONTHNAME(issue_date) as month_name
    FROM certificates 
    WHERE issue_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
    GROUP BY YEAR(issue_date), MONTH(issue_date)
    ORDER BY year, month
");

// Get top students by certificate count
$topStudents = $conn->query("
    SELECT 
        student_id,
        COUNT(*) as certificate_count
    FROM certificates 
    GROUP BY student_id 
    ORDER BY certificate_count DESC 
    LIMIT 5
");

// Get internship distribution
$internshipStats = $conn->query("
    SELECT 
        internship_id,
        COUNT(*) as count
    FROM certificates 
    GROUP BY internship_id 
    ORDER BY count DESC 
    LIMIT 10
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate Management - Dashboard</title>
    <link rel="stylesheet" href="index.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
</head>
<body>
    <div class="main-container">
        <!-- Page Header -->
        <div class="page-header fade-in">
            <h1>DASHBOARD</h1>
            <p class="page-subtitle">Certificate management overview and analytics</p>
        </div>

        <!-- Navigation -->
        <nav class="nav-container slide-in">
            <ul class="nav-menu">
                <li class="nav-item" onclick="window.location.href='index.php'">View Certificates</li>
                <li class="nav-item" onclick="window.location.href='add_certificate.php'">Add Certificate</li>
                <li class="nav-item active">Dashboard</li>
                <li class="nav-item" onclick="window.location.href='reports.php'">Reports</li>
            </ul>
        </nav>

        <!-- Statistics Cards -->
        <div class="stats-grid fade-in">
            <div class="glass-card stat-card">
                <div class="stat-icon"></div>
                <div class="stat-content">
                    <h3>Total Certificates</h3>
                    <div class="stat-number"><?php echo $totalCertificates; ?></div>
                    <span class="stat-label">All time</span>
                </div>
            </div>
            
            <div class="glass-card stat-card">
                <div class="stat-icon"></div>
                <div class="stat-content">
                    <h3>This Month</h3>
                    <div class="stat-number"><?php echo $thisMonth; ?></div>
                    <span class="stat-label">Certificates issued</span>
                </div>
            </div>
            
            <div class="glass-card stat-card">
                <div class="stat-icon"></div>
                <div class="stat-content">
                    <h3>This Week</h3>
                    <div class="stat-number"><?php echo $thisWeek; ?></div>
                    <span class="stat-label">New certificates</span>
                </div>
            </div>
            
            <div class="glass-card stat-card">
                <div class="stat-icon"></div>
                <div class="stat-content">
                    <h3>Today</h3>
                    <div class="stat-number"><?php echo $today; ?></div>
                    <span class="stat-label">Issued today</span>
                </div>
            </div>
        </div>

        <!-- Charts Section -->
        <div class="dashboard-grid">
            <!-- Monthly Trend Chart -->
            <div class="glass-card chart-container">
                <h3>Certificate Issuance Trend</h3>
                <canvas id="monthlyChart"></canvas>
            </div>

            <!-- Top Students -->
            <div class="glass-card">
                <h3>Top Students by Certificates</h3>
                <div class="student-list">
                    <?php if ($topStudents && $topStudents->num_rows > 0): ?>
                        <?php $rank = 1; ?>
                        <?php while ($student = $topStudents->fetch_assoc()): ?>
                            <div class="student-item">
                                <div class="student-rank"><?php echo $rank++; ?></div>
                                <div class="student-info">
                                    <strong>Student ID: <?php echo htmlspecialchars($student['student_id']); ?></strong>
                                    <span><?php echo $student['certificate_count']; ?> certificates</span>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p>No student data available</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="glass-card">
            <div class="flex justify-between items-center mb-4">
                <h3>Recent Certificates</h3>
                <a href="index.php" class="btn btn-primary">View All</a>
            </div>
            
            <?php if ($recentCertificates && $recentCertificates->num_rows > 0): ?>
                <div class="recent-table">
                    <table>
                        <thead>
                            <tr>
                                <th>Certificate ID</th>
                                <th>Student ID</th>
                                <th>Internship ID</th>
                                <th>Issue Date</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($cert = $recentCertificates->fetch_assoc()): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($cert['certificate_id']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($cert['student_id']); ?></td>
                                    <td><?php echo htmlspecialchars($cert['internship_id']); ?></td>
                                    <td>
                                        <?php 
                                        $date = new DateTime($cert['issue_date']);
                                        echo $date->format('d/m/Y'); 
                                        ?>
                                    </td>
                                    <td><span class="status-badge status-approved">Active</span></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>No recent certificates found</p>
            <?php endif; ?>
        </div>

        <!-- Internship Distribution -->
        <div class="glass-card">
            <h3>Certificate Distribution by Internship</h3>
            <div class="internship-stats">
                <?php if ($internshipStats && $internshipStats->num_rows > 0): ?>
                    <?php while ($stat = $internshipStats->fetch_assoc()): ?>
                        <div class="internship-item">
                            <div class="internship-info">
                                <strong>Internship ID: <?php echo htmlspecialchars($stat['internship_id']); ?></strong>
                                <span><?php echo $stat['count']; ?> certificates</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress" style="width: <?php echo min(($stat['count'] / $totalCertificates) * 100, 100); ?>%"></div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>No internship data available</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Monthly trend chart
        const ctx = document.getElementById('monthlyChart').getContext('2d');
        
        // Prepare data for chart
        const monthlyData = [
            <?php 
            $chartData = [];
            if ($monthlyData && $monthlyData->num_rows > 0) {
                while ($data = $monthlyData->fetch_assoc()) {
                    $chartData[] = "{label: '" . $data['month_name'] . "', value: " . $data['count'] . "}";
                }
            }
            echo implode(',', $chartData);
            ?>
        ];

        const labels = monthlyData.map(item => item.label);
        const values = monthlyData.map(item => item.value);

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Certificates Issued',
                    data: values,
                    borderColor: '#8B5CF6',
                    backgroundColor: 'rgba(139, 92, 246, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: 'rgba(255, 255, 255, 0.7)'
                        }
                    },
                    x: {
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        },
                        ticks: {
                            color: 'rgba(255, 255, 255, 0.7)'
                        }
                    }
                }
            }
        });

        // Add interactive behavior
        document.addEventListener('DOMContentLoaded', function() {
            // Animate stat numbers on load
            const statNumbers = document.querySelectorAll('.stat-number');
            statNumbers.forEach(stat => {
                const finalValue = parseInt(stat.textContent);
                let currentValue = 0;
                const increment = Math.ceil(finalValue / 50);
                
                const timer = setInterval(() => {
                    currentValue += increment;
                    if (currentValue >= finalValue) {
                        currentValue = finalValue;
                        clearInterval(timer);
                    }
                    stat.textContent = currentValue;
                }, 30);
            });

            // Add hover effects to cards
            const cards = document.querySelectorAll('.glass-card');
            cards.forEach(card => {
                card.addEventListener('mouseenter', function() {
                    this.style.transform = 'translateY(-5px) scale(1.02)';
                });
                card.addEventListener('mouseleave', function() {
                    this.style.transform = 'translateY(0) scale(1)';
                });
            });
        });
    </script>

    <style>
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1.5rem;
        }

        .stat-icon {
            font-size: 2rem;
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(139, 92, 246, 0.1);
            border-radius: 12px;
        }

        .stat-content h3 {
            margin: 0 0 0.5rem 0;
            font-size: 0.9rem;
            opacity: 0.8;
        }

        .stat-number {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary-purple);
            margin-bottom: 0.25rem;
        }

        .stat-label {
            font-size: 0.8rem;
            opacity: 0.6;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .chart-container {
            padding: 1.5rem;
            height: 400px;
        }

        .chart-container canvas {
            max-height: 300px !important;
        }

        .student-list {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .student-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 8px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .student-rank {
            font-size: 1.2rem;
            font-weight: 700;
            color: var(--primary-purple);
            min-width: 30px;
        }

        .student-info {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }

        .student-info span {
            font-size: 0.9rem;
            opacity: 0.7;
        }

        .recent-table {
            overflow-x: auto;
        }

        .internship-stats {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .internship-item {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .internship-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .progress-bar {
            height: 8px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 4px;
            overflow: hidden;
        }

        .progress {
            height: 100%;
            background: linear-gradient(135deg, var(--primary-purple), var(--accent-pink));
            border-radius: 4px;
            transition: width 0.3s ease;
        }

        @media (max-width: 768px) {
            .dashboard-grid {
                grid-template-columns: 1fr;
            }
            
            .stats-grid {
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            }
        }
    </style>
</body>
</html>

<?php $conn->close(); ?>