<?php

$conn = new mysqli('127.0.0.1', 'root', '', 'webdata');
if ($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}

function checkUsername($username){
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username); // "s" = string
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

function checkEmail($email){
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}
?>
