<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate Management - Add Certificate</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="index.css">
    <style>
        /* Fix dropdown text visibility */
        select option {
            color: #000000 !important;
            background-color: #ffffff !important;
        }
        
        select {
            color: #000000 !important;
        }
        
        select:focus {
            color: #000000 !important;
        }
        
        /* Ensure dropdown options are visible */
        select option:checked {
            background-color: #007bff !important;
            color: #ffffff !important;
        }

        /* Hide messages by default */
        .alert {
            display: none;
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 8px;
            font-weight: 500;
        }

        .alert-success {
            background: rgba(34, 197, 94, 0.1);
            border: 1px solid rgba(34, 197, 94, 0.3);
            color: #22c55e;
        }

        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #ef4444;
        }
    </style>
</head>
<body>
    <div class="main-container">
        <!-- Page Header -->
        <div class="page-header fade-in">
            <h1>CERTIFICATE MANAGEMENT</h1>
            <p class="page-subtitle">Add a new certificate to the system</p>
        </div>

        <!-- Form Container -->
        <div class="fade-in">
            <form action="insert_connection.php" method="post" id="certificateForm">
                <h2 class="text-center mb-3">Add New Certificate</h2>
                <p class="text-center mb-4" style="color: var(--text-secondary);">
                    Fill in the details below to create a new certificate record
                </p>

                <!-- Messages - Hidden by default -->
                <div class="alert alert-success" id="successMessage">
                    Certificate added successfully!
                </div>
                <div class="alert alert-error" id="errorMessage">
                    Please fill in all required fields correctly.
                </div>

                <div class="form-group">
                    <label for="certificate_id">Certificate ID</label>
                    <input type="text" 
                           id="certificate_id" 
                           name="certificate_id" 
                           placeholder="Enter certificate ID (e.g., CERT-2024-001)" 
                           required>
                </div>

                <div class="form-group">
                    <label for="student_id">Student ID</label>
                    <input type="text" 
                           id="student_id" 
                           name="student_id" 
                           placeholder="Enter student ID (e.g., STU-2024-001)" 
                           required>
                </div>

                <div class="form-group">
                    <label for="internship_id">Internship ID</label>
                    <input type="text" 
                           id="internship_id" 
                           name="internship_id" 
                           placeholder="Enter internship ID (e.g., INT-2024-001)" 
                           required>
                </div>

                <div class="form-group">
                    <label for="issue_date">Issue Date</label>
                    <input type="date" 
                           id="issue_date" 
                           name="issue_date" 
                           required>
                </div>

                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="resetForm()">Reset Form</button>
                    <button type="submit" class="btn btn-primary">Add Certificate</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Set today's date as default for issue date
        document.getElementById('issue_date').valueAsDate = new Date();

        // Navigation function
        function navigateTo(page) {
            switch(page) {
                case 'view':
                    window.location.href = 'view_certificates.php';
                    break;
                case 'dashboard':
                    window.location.href = 'dashboard.php';
                    break;
                case 'reports':
                    window.location.href = 'reports.php';
                    break;
                default:
                    console.log('Unknown navigation target');
            }
        }

        // Reset form function
        function resetForm() {
            document.getElementById('certificateForm').reset();
            document.getElementById('issue_date').valueAsDate = new Date();
            document.getElementById('certificate_id').value = generateCertificateId();
            hideMessages();
        }

        // Show/hide messages
        function showMessage(type, message) {
            hideMessages();
            const messageEl = document.getElementById(type + 'Message');
            if (messageEl) {
                if (message) messageEl.textContent = message;
                messageEl.style.display = 'block';
                setTimeout(hideMessages, 5000);
            }
        }

        function hideMessages() {
            document.getElementById('successMessage').style.display = 'none';
            document.getElementById('errorMessage').style.display = 'none';
        }

        // Form submission handler
        document.getElementById('certificateForm').addEventListener('submit', function(e) {
            // Basic validation before submission
            const requiredFields = this.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    isValid = false;
                    field.style.borderColor = 'var(--danger-red)';
                } else {
                    field.style.borderColor = 'var(--glass-border)';
                }
            });

            if (!isValid) {
                e.preventDefault(); // Only prevent submission if validation fails
                showMessage('error', 'Please fill in all required fields correctly.');
                return false;
            }
            
            // If validation passes, allow form to submit normally
            // The success message will be shown after redirect from insert_connection.php
        });

        // Auto-generate certificate ID based on current date
        function generateCertificateId() {
            const now = new Date();
            const year = now.getFullYear();
            const month = String(now.getMonth() + 1).padStart(2, '0');
            const day = String(now.getDate()).padStart(2, '0');
            const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
            return `CERT-${year}${month}${day}-${random}`;
        }

        // Page initialization - FIXED: Only show messages if they come from URL parameters
        document.addEventListener('DOMContentLoaded', function() {
            // Generate certificate ID if field is empty
            const certIdField = document.getElementById('certificate_id');
            if (!certIdField.value) {
                certIdField.value = generateCertificateId();
            }
            
            // FIXED: Only check for success/error messages from URL parameters
            // This ensures messages only appear after form submission redirect
            const urlParams = new URLSearchParams(window.location.search);
            
            if (urlParams.has('success') && urlParams.get('success') === '1') {
                showMessage('success', 'Certificate added successfully!');
                // Clear the form after successful submission
                setTimeout(() => {
                    document.getElementById('certificateForm').reset();
                    document.getElementById('issue_date').valueAsDate = new Date();
                    document.getElementById('certificate_id').value = generateCertificateId();
                    // Clean up URL parameters
                    window.history.replaceState({}, document.title, window.location.pathname);
                }, 3000);
            } else if (urlParams.has('error') && urlParams.get('error') === '1') {
                showMessage('error', 'There was an error adding the certificate. Please try again.');
                // Clean up URL parameters after error message
                setTimeout(() => {
                    window.history.replaceState({}, document.title, window.location.pathname);
                }, 5000);
            }
            
            // Ensure messages are hidden on fresh page load (no URL parameters)
            if (!urlParams.has('success') && !urlParams.has('error')) {
                hideMessages();
            }
        });

        // Real-time validation feedback
        document.querySelectorAll('input[required], select[required]').forEach(field => {
            field.addEventListener('blur', function() {
                if (!this.value.trim()) {
                    this.style.borderColor = 'var(--danger-red)';
                } else {
                    this.style.borderColor = 'var(--success-green)';
                }
            });
        });

        // Ensure dropdown text remains black after selection
        document.querySelectorAll('select').forEach(select => {
            select.addEventListener('change', function() {
                this.style.color = '#000000';
            });
        });
    </script>
</body>
</html>